/**
 * social-network router
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::social-network.social-network');
